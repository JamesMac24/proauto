--
-- PostgreSQL database dump
--

\restrict wZa2B5HboqTWqG8GFIpT5d2AJWVZ0VAfxK3EzArWMsErf38CznuUc0bkJLN2JKx

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS "proauto_acceso_piloto" ON "public"."taller_datos";
ALTER TABLE IF EXISTS ONLY "public"."taller_datos" DROP CONSTRAINT IF EXISTS "taller_datos_pkey";
DROP TABLE IF EXISTS "public"."taller_datos";
DROP FUNCTION IF EXISTS "public"."rls_auto_enable"();
DROP SCHEMA IF EXISTS "public";
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."rls_auto_enable"() RETURNS "event_trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taller_datos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."taller_datos" (
    "id" integer NOT NULL,
    "data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Data for Name: taller_datos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."taller_datos" ("id", "data", "updated_at") FROM stdin;
1	{}	2026-09-25 21:01:40.504927+00
\.


--
-- Name: taller_datos taller_datos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."taller_datos"
    ADD CONSTRAINT "taller_datos_pkey" PRIMARY KEY ("id");


--
-- Name: taller_datos proauto_acceso_piloto; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "proauto_acceso_piloto" ON "public"."taller_datos" USING (true) WITH CHECK (true);


--
-- Name: taller_datos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."taller_datos" ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict wZa2B5HboqTWqG8GFIpT5d2AJWVZ0VAfxK3EzArWMsErf38CznuUc0bkJLN2JKx

