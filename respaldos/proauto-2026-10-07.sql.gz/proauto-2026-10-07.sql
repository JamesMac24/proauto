--
-- PostgreSQL database dump
--

\restrict RhropWCp98CDidC3bHaUIHFQUZtyFh0bouCDhaqTxxGl8RRhsJAbxhG5EKCI0V9

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS "proauto_acceso_piloto" ON "public"."taller_datos";
ALTER TABLE IF EXISTS ONLY "public"."taller_datos" DROP CONSTRAINT IF EXISTS "taller_datos_pkey";
DROP TABLE IF EXISTS "public"."taller_datos";
DROP FUNCTION IF EXISTS "public"."rls_auto_enable"();
DROP SCHEMA IF EXISTS "public";
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."rls_auto_enable"() RETURNS "event_trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taller_datos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."taller_datos" (
    "id" integer NOT NULL,
    "data" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Data for Name: taller_datos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."taller_datos" ("id", "data", "updated_at") FROM stdin;
1	{"ots": [{"id": "OTI-M-0041", "area": "Mecánica", "fecha": "19/07", "marca": "Toyota", "monto": 445, "estado": "EN PROCESO", "cliente": "Juan Paredes Sánchez", "entrega": "Hoy · 5:00 pm", "maestro": "Nelson", "trabajo": "Cambio de aceite y filtros; Revisión de frenos", "vehiculo": "Corolla · ABC-123"}, {"id": "OTI-M-0042", "area": "Mecánica", "fecha": "19/07", "marca": "Chevrolet", "monto": 680, "estado": "APROBADA", "cliente": "María Gonzales Torres", "entrega": "Mañana", "maestro": "Carlos", "trabajo": "Cambio de pastillas; Rectificado de discos", "vehiculo": "Aveo · DEF-456"}, {"id": "OTI-T-0043", "mat": 60, "area": "Tornería", "fecha": "19/07", "monto": 480, "pieza": "Cigüeñal", "estado": "EN PROCESO", "cliente": "Carlos Mendoza Ruiz", "entrega": "Hoy · 5:00 pm", "maestro": "Gabriela", "trabajo": "Rectificado de cigüeñal"}, {"id": "OTI-M-0044", "area": "Mecánica", "fecha": "19/07", "marca": "Kia", "monto": 1520, "estado": "INGRESO", "cliente": "Ana Vera Campos", "entrega": "", "maestro": "Nelson", "trabajo": "Mantenimiento de 20 mil km", "vehiculo": "Sportage · JKL-321"}, {"id": "OTI-T-0045", "mat": 35, "area": "Tornería", "fecha": "19/07", "monto": 285, "pieza": "Eje trasero", "estado": "ENTREGADA", "cliente": "Roberto Silva Peña", "entrega": "Hoy · 3:00 pm", "maestro": "Aldair", "trabajo": "Torneado de eje trasero"}, {"id": "OTI-M-0038", "area": "Mecánica", "fecha": "03/07", "marca": "Toyota", "monto": 320, "estado": "ENTREGADA", "cliente": "Juan Paredes Sánchez", "entrega": "04/07", "maestro": "Nelson", "trabajo": "Revisión general", "vehiculo": "Corolla · ABC-123"}], "otSeq": {"M": 46, "T": 45}, "gastos": [{"id": 1790378621871, "area": "Repuestos", "desc": "Ejemplo", "hora": "18:23", "total": 10, "metodo": "Efectivo", "categoria": "Subvención alimentaria", "trabajador": "Karina"}, {"id": 1790378575712, "area": "Tornería", "desc": "Citofonte - ", "hora": "18:22", "total": 5, "metodo": "Efectivo", "categoria": "Otros gastos operativos", "trabajador": ""}, {"id": 1, "area": "Mecánica", "desc": "Empaque de motor", "hora": "10:00", "total": 95, "metodo": "Efectivo", "categoria": "Compra de repuestos e insumos", "trabajador": ""}, {"id": 2, "area": "General", "desc": "Almuerzo del personal", "hora": "12:30", "total": 60, "metodo": "Efectivo", "categoria": "Subvención alimentaria", "trabajador": "Todos"}, {"id": 3, "area": "General", "desc": "Cuota préstamo Sra. Ofelia", "hora": "14:15", "total": 120, "metodo": "Efectivo", "categoria": "Pago de préstamo (prestamista)", "trabajador": ""}, {"id": 4, "area": "Tornería", "desc": "Cuchillas para torno", "hora": "15:00", "total": 85, "metodo": "Yape", "categoria": "Compra de repuestos e insumos", "trabajador": ""}, {"id": 5, "area": "General", "desc": "Adelanto de sueldo", "hora": "11:20", "total": 50, "metodo": "Efectivo", "categoria": "Adelanto de sueldo a personal", "trabajador": "Aldair"}], "tareas": [{"id": 1, "dia": "Hoy", "hecho": false, "tarea": "Limpieza del baño", "frecuencia": "Diaria (rotativa)", "responsable": "Carlos"}, {"id": 2, "dia": "Hoy", "hecho": false, "tarea": "Barrido general del taller", "frecuencia": "Diaria — fin de jornada", "responsable": "Todos"}, {"id": 3, "dia": "Hoy", "hecho": false, "tarea": "Orden de herramientas del puesto", "frecuencia": "Diaria — cierre", "responsable": "Cada técnico"}, {"id": 4, "dia": "Lunes", "hecho": true, "tarea": "Revisión y engrase de máquinas", "frecuencia": "Semanal", "responsable": "Gabriela"}, {"id": 5, "dia": "Mié y Sáb", "hecho": false, "tarea": "Sacar residuos y chatarra", "frecuencia": "2 veces por semana", "responsable": "Aldair"}, {"id": 6, "dia": "Viernes", "hecho": false, "tarea": "Conteo rápido de inventario", "frecuencia": "Semanal", "responsable": "Karina"}, {"id": 7, "dia": "Sábado por la tarde", "hecho": false, "tarea": "Limpieza profunda del taller", "frecuencia": "Semanal", "responsable": "Todos"}], "movsInv": [{"id": 1, "por": "Karina", "cant": 10, "tipo": "Ingreso", "fecha": "15/07", "codigo": "7501234567890", "precio": 18}, {"id": 2, "por": "Karina", "cant": 6, "tipo": "Venta", "fecha": "17/07", "codigo": "7501234567890", "precio": 28}, {"id": 3, "por": "Karina", "cant": 2, "tipo": "Venta", "fecha": "19/07", "codigo": "7501234567890", "precio": 28}, {"id": 4, "por": "Karina", "cant": 8, "tipo": "Ingreso", "fecha": "12/07", "codigo": "7501234567896", "precio": 22}, {"id": 5, "por": "Karina", "cant": 5, "tipo": "Venta", "fecha": "16/07", "codigo": "7501234567896", "precio": 35}, {"id": 6, "por": "Karina", "cant": 3, "tipo": "Venta", "fecha": "18/07", "codigo": "7501234567896", "precio": 35}, {"id": 7, "por": "Karina", "cant": 3, "tipo": "Venta", "fecha": "19/07", "codigo": "7501234567891", "precio": 95}, {"id": 1790378711952.6702, "por": "Karina", "cant": 3, "tipo": "Venta", "fecha": "19/07", "codigo": "7501234567893", "precio": 42}], "clientes": [{"dni": "45678912", "nombre": "Juan Paredes Sánchez", "visitas": 8, "telefono": "987 654 321", "vehiculos": [{"marca": "Toyota", "placa": "ABC-123", "modelo": "Corolla"}]}, {"dni": "40123456", "nombre": "María Gonzales Torres", "visitas": 3, "telefono": "998 877 665", "vehiculos": [{"marca": "Chevrolet", "placa": "DEF-456", "modelo": "Aveo"}]}, {"dni": "42987654", "nombre": "Carlos Mendoza Ruiz", "visitas": 12, "telefono": "965 432 198", "vehiculos": [{"marca": "Kia", "placa": "GHI-789", "modelo": "Sportage"}]}], "ingresos": [{"id": 1790378711952, "area": "Repuestos", "cant": 3, "desc": "OSI-R-0025 · 3× Bujía iridium", "hora": "18:25", "banco": "", "total": 126, "metodo": "Efectivo"}, {"id": 1790378403649, "area": "Tornería", "cant": 1, "desc": "Cobro OTI-T-0045 — Eje trasero — parte Yape", "hora": "18:20", "banco": "", "total": 185, "metodo": "Yape"}, {"id": 1790378403648, "area": "Tornería", "cant": 1, "desc": "Cobro OTI-T-0045 — Eje trasero — parte Efectivo", "hora": "18:20", "banco": "", "total": 100, "metodo": "Efectivo"}, {"id": 1, "area": "Mecánica", "cant": 1, "desc": "Cobro OTI-M-0038 — Toyota Corolla", "hora": "09:15", "banco": "", "total": 320, "metodo": "Efectivo"}, {"id": 2, "area": "Repuestos", "cant": 2, "desc": "OSI-R-0021 · Filtro de aceite Fram", "hora": "10:22", "banco": "", "total": 56, "metodo": "Efectivo"}, {"id": 3, "area": "Repuestos", "cant": 3, "desc": "OSI-R-0022 · Pastillas de freno Bosch", "hora": "13:05", "banco": "", "total": 135, "metodo": "Yape"}, {"id": 4, "area": "Mecánica", "cant": 1, "desc": "Abono OTI-M-0041", "hora": "15:30", "banco": "", "total": 240, "metodo": "Efectivo"}, {"id": 5, "area": "Repuestos", "cant": 4, "desc": "OSI-R-0023 · Bujías NGK iridium", "hora": "16:10", "banco": "", "total": 100, "metodo": "Plin"}], "mensajes": [{"de": "Tony", "id": 1, "hora": "07:55", "texto": "Buen día equipo. Hoy llega el cliente del Sportage a las 10, atención con eso."}, {"de": "Nelson", "id": 2, "hora": "08:20", "texto": "Recibido. El Corolla ya está en proceso, termino antes del mediodía."}, {"de": "Karina", "id": 3, "hora": "09:10", "texto": "Llegaron los filtros Fram que faltaban, ya ingresados al inventario."}, {"de": "Gabriela", "id": 4, "hora": "10:05", "texto": "El cigüeñal del Sr. Mendoza queda listo hoy a las 4pm 👍"}], "personas": [{"id": 1, "ini": "TO", "rec": "", "rol": "admin", "pass": null, "cargo": "Administrador · Dueño", "nombre": "Tony"}, {"id": 2, "ini": "KA", "rec": "973607253", "rol": "caja", "pass": "1976", "cargo": "Asesora de Servicio", "nombre": "Karina"}, {"id": 3, "ini": "NE", "rec": "", "rol": "mecanico", "pass": null, "cargo": "Técnico Automotriz", "nombre": "Nelson"}, {"id": 4, "ini": "CA", "rec": "", "rol": "mecanico", "pass": null, "cargo": "Técnico Automotriz", "nombre": "Carlos"}, {"id": 5, "ini": "GA", "rec": "", "rol": "tornero", "pass": null, "cargo": "Técnica en Tornería", "nombre": "Gabriela"}, {"id": 6, "ini": "AL", "rec": "", "rol": "tornero", "pass": null, "cargo": "Técnico en Tornería", "nombre": "Aldair"}], "ventaSeq": 25, "inventario": [{"marca": "Fram", "stock": 2, "codigo": "7501234567890", "minimo": 5, "nombre": "Filtro de aceite universal", "precio": 28}, {"marca": "Bosch", "stock": 1, "codigo": "7501234567891", "minimo": 3, "nombre": "Pastillas de freno delanteras", "precio": 95}, {"marca": "Mobil", "stock": 4, "codigo": "7501234567892", "minimo": 6, "nombre": "Aceite de motor 20W-50", "precio": 75}, {"marca": "NGK", "stock": 21, "codigo": "7501234567893", "minimo": 8, "nombre": "Bujía iridium", "precio": 42}, {"marca": "Gates", "stock": 6, "codigo": "7501234567894", "minimo": 3, "nombre": "Correa de distribución", "precio": 150}, {"marca": "Monroe", "stock": 8, "codigo": "7501234567895", "minimo": 4, "nombre": "Amortiguador delantero", "precio": 220}, {"marca": "Wagner", "stock": 0, "codigo": "7501234567896", "minimo": 4, "nombre": "Líquido de frenos DOT4", "precio": 35}, {"marca": "Prestone", "stock": 0, "codigo": "7501234567897", "minimo": 6, "nombre": "Refrigerante verde 1L", "precio": 28}], "materiales": [{"id": 1, "area": "Tornería", "costo": 9.5, "stock": 42, "minimo": 15, "nombre": "Barra de acero 1045", "unidad": "kg"}, {"id": 2, "area": "Tornería", "costo": 22, "stock": 6, "minimo": 4, "nombre": "Bocina de bronce", "unidad": "unid."}, {"id": 3, "area": "Tornería", "costo": 18, "stock": 3, "minimo": 2, "nombre": "Soldadura supercito", "unidad": "kg"}, {"id": 4, "area": "Tornería", "costo": 15, "stock": 8, "minimo": 4, "nombre": "Cuchillas de torno", "unidad": "unid."}, {"id": 5, "area": "Mecánica", "costo": 14, "stock": 18, "minimo": 10, "nombre": "Aceite a granel 20W-50", "unidad": "L"}, {"id": 6, "area": "Mecánica", "costo": 16, "stock": 5, "minimo": 3, "nombre": "Grasa multiuso", "unidad": "kg"}, {"id": 7, "area": "Mecánica", "costo": 4, "stock": 7, "minimo": 4, "nombre": "Waype / trapos", "unidad": "kg"}, {"id": 8, "area": "Mecánica", "costo": 12, "stock": 4, "minimo": 3, "nombre": "Silicona / sellador", "unidad": "unid."}], "sugerencias": [{"de": "Aldair", "id": 1, "ot": "OTI-T-0045", "texto": "Su eje quedó torneado y balanceado. Se recomienda revisar los rodamientos en el próximo mantenimiento.", "estado": "pendiente"}]}	2026-10-06 02:05:15.093+00
\.


--
-- Name: taller_datos taller_datos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."taller_datos"
    ADD CONSTRAINT "taller_datos_pkey" PRIMARY KEY ("id");


--
-- Name: taller_datos proauto_acceso_piloto; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "proauto_acceso_piloto" ON "public"."taller_datos" USING (true) WITH CHECK (true);


--
-- Name: taller_datos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."taller_datos" ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict RhropWCp98CDidC3bHaUIHFQUZtyFh0bouCDhaqTxxGl8RRhsJAbxhG5EKCI0V9

